import java.awt.font.NumericShaper;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

/**
 * Created by James Veith on 4/7/2015.
 */
public class SkyscraperConfig implements Configuration{

    private int dim;
    private int[] top;
    private int[] bot;
    private int[] left;
    private int[] right;
    private int[][] board;
    private int[] startCoors = new int[2];

    public SkyscraperConfig(Scanner f){
        dim = f.nextInt();
        top = new int[dim];
        bot = new int[dim];
        left = new int[dim];
        right = new int[dim];
        board = new int[dim][dim];

        for (int i = 0; i < dim; i++) {
            top[i] = f.nextInt();
        }
        for (int i = 0; i < dim; i++) {
            right[i] = f.nextInt();
        }
        for (int i = 0; i < dim; i++) {
            bot[i] = f.nextInt();
        }
        for (int i = 0; i < dim; i++) {
            left[i] = f.nextInt();
        }
        boolean foundStart = false;
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                board[i][j] = f.nextInt();
                if (!foundStart && board[i][j]==0) {
                    startCoors[0] = i;
                    startCoors[1] = j;
                }
                //System.out.print(board[i][j]);//tests initial board values
            }
            //System.out.println();
        }
    }

    public SkyscraperConfig(SkyscraperConfig copy) {
        this.dim = copy.dim;
        this.startCoors = copy.startCoors;
        this.top = copy.top;
        this.bot = copy.bot;
        this.left = copy.left;
        this.right = copy.right;
        this.board = copy.board;
        for (int i = 0; i < dim; i++) {
            top[i] = copy.top[i];
        }
        for (int i = 0; i < dim; i++) {
            bot[i] = copy.bot[i];
        }
        for (int i = 0; i < dim; i++) {
            left[i] = copy.left[i];
        }
        for (int i = 0; i < dim; i++) {
            right[i] = copy.right[i];
        }
        boolean foundStart = false;
        for (int i = 0; i < dim; i++) {
            for (int j = 0; j < dim; j++) {
                board[i][j] = copy.top[i];
                if (!foundStart && board[i][j]==0) {
                    startCoors[0] = i;
                    startCoors[1] = j;
                }
                //System.out.print(board[i][j]);//tests initial board values
            }
            //System.out.println();
        }
    }

    /**
     * Get the collection of successors from the current one.
     *
     * @return All successors, valid and invalid
     */
    @Override
    public Collection<Configuration> getSuccessors() {
        Collection<Configuration> successors = new ArrayList<Configuration>();
        for (int i = 1; i <= dim; i++) {
            SkyscraperConfig successor = new SkyscraperConfig(new SkyscraperConfig(this));
            successor.board[startCoors[0]][startCoors[1]] = i;
            successors.add(successor);
        }
        //System.out.println(successors);
        return successors;
    }

    /**
     * Is the current configuration valid or not?
     *
     * @return true if valid; false otherwise
     */
    @Override
    public boolean isValid() {
        //checks duplicates
        ArrayList<Integer> legalVals = new ArrayList<Integer>(dim);
        for (int i = 1; i <= dim; i++) {
            legalVals.add(i);
        }
        for (int i = 0; i < dim; i++) {
            if (!legalVals.contains(this.board[i][startCoors[1]])){
                return false;
            }else {
                legalVals.remove(legalVals.indexOf(this.board[i][startCoors[1]]));
            }
        }
        return true;
    }

    /**
     * Is the current configuration a goal?
     *
     * @return true if goal; false otherwise
     */
    @Override
    public boolean isGoal() {
        return (startCoors[0]==dim && startCoors[1]==dim);
    }

    public String toString(){
        String form = "  ";
        for (int i = 0; i < dim; i++) {
            form += top[i] + " ";
        }
        form += "\n" + "  ";
        for (int i = 0; i < dim; i++) {
            form += "--";
        }
        form += "\n";
        for (int i = 0; i < dim; i++) {
            form += left[i] + "|";
            for (int j = 0; j < dim; j++) {
                if (board[i][j] == 0){
                    form += ". ";
                }else{
                    form += board[i][j] + " ";
                }
            }
            form = form.substring(0, form.length()-1);//remove the last space
            form += "|" + right[i] + "\n";
        }
        form += "  ";
        for (int i = 0; i < dim; i++) {
            form += "--";
        }
        form += "\n  ";
        for (int i = 0; i < dim; i++) {
            form += bot[i] + " ";
        }

        return form;
    }
}
